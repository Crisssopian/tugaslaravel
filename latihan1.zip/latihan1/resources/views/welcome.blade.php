<!DOCTYPE HTML>

<html>

<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<title>Kriis</title>
	<link rel="stylesheet" href="assets/style.css">
    <style>
        body {
    background-color: #d8d0d0;
}

.wrapper {
    background-color: #333;
    color: #fffffffa;
    padding: 0px;
    width: 700px;
    height: auto;
    margin: 100px auto;
    font-family: arial;
}

.header-atas ul {
    margin: 0;
    padding: 0;
    list-style: none;
}

.header-atas ul li {
    float: left;
    padding: 5px;
}

.artikel h2 {
    font-weight: 100;
}

.header-atas ul li:hover {
    float: left;
    background-color: #9a3cab;
    transition: 0.3s;
    cursor: pointer;
}

.header-atas {
    margin: 0;
    padding: 8px;
    width: auto;
    height: 30px;
    background-color: #8900a2;
}

.artikel {
    background-color: #3e1246;
    text-align: center;
    padding: 5px;
    text-transform: uppercase;
}

.about {
    background-color: #f1f1f1;
    border-left: solid 1px #8900a2;
    border-right: solid 1px #8900a2;
}

.about p {
    font-size: 13px;
    text-align: center;
    padding-bottom: 10px;
    color: #3e1246;
}

.about h2 {
    text-align: center;
    font-size: 18px;
    color: #3b393c;
    margin: 0;
    padding: 7px;
    text-transform: uppercase;
}

footer {
    font-size: 12px;
    text-align: right;
    padding: 2px;
    margin: 0;
    background: #8900a2;
}

footer p {
    padding: 0 5px;
}
    </style>
</head>

<body>
<div class="wrapper">
	<div class="header-atas">
	<header>
		<nav>
			<ul>
				<li>Beranda</li>
				<li>Kontak</li>
			</ul>
		</nav>
	</header>
	</div>

	<div class="artikel">
	<section>
	
		<article>
			<header>
				<h2>KRIIS SOPIAN</h2>
			</header>
		</article>
		
	</section>
	</div>

	<div class="about">
	<aside>
		<h2>Motto Hidup</h2>
		<p> "Untuk meraih kesuksesan, hal yang harus kita tanggalkan adalah batasan. Sementara hal yang harus kita hilangkan adalah sikap malas dan tak berani bertanggung jawab."</p>
	</aside>
	</div>

	<footer>
		<p>Latihan 1</p>
	</footer>
</div>
</body>

</html>